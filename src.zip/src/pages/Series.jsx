import CheckComponent from "../components/check-component/CheckComponent";

const Series = ({ data }) => {
    return <CheckComponent data={data} Index={1} />;
};

export default Series;
