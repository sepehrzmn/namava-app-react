import CheckComponent from "../components/check-component/CheckComponent";

const Latest = ({ data }) => {
    return <CheckComponent data={data} Index={1} />;
};

export default Latest;
