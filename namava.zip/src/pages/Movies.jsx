import CheckComponent from "../components/check-component/CheckComponent";

const Movies = ({ data }) => {
    return <CheckComponent data={data} Index={1} />;
};

export default Movies;
