import CheckComponent from "../components/check-component/CheckComponent";

const Index = ({ data }) => {
    return <CheckComponent data={data} Index={2} />;
};

export default Index;
