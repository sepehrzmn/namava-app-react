const CheckComponentTag = ({ pageTags }) => {
    return <div>CheckComponentTag</div>;
};

export default CheckComponentTag;
